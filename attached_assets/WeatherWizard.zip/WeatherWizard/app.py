import streamlit as st
import json
import pandas as pd
import os
from datetime import datetime, timedelta

from data_fetcher import (
    get_current_weather, 
    get_climate_change_data, 
    get_air_quality_data,
    get_satellite_imagery_data,
    get_flood_data
)
from ai_handler import get_ai_response
from utils import display_weather_summary, create_data_visualization

# Page configuration
st.set_page_config(
    page_title="Climate Q&A Assistant",
    page_icon="🌍",
    layout="wide"
)

# Default coordinates (Hanoi, Vietnam) from the provided APIs
DEFAULT_LAT = 21.0245
DEFAULT_LON = 105.8412

def initialize_session_state():
    """Initialize session state variables if they don't exist"""
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    if 'current_lat' not in st.session_state:
        st.session_state.current_lat = DEFAULT_LAT
    if 'current_lon' not in st.session_state:
        st.session_state.current_lon = DEFAULT_LON
    if 'api_data_cache' not in st.session_state:
        st.session_state.api_data_cache = {}
    if 'last_cache_update' not in st.session_state:
        st.session_state.last_cache_update = datetime.now() - timedelta(hours=2)  # Force initial update

initialize_session_state()

# Title and introduction
st.title("🌍 Climate Change & Weather Q&A")
st.markdown("""
Ask questions about current weather conditions, climate change projections, 
air quality, or other environmental data. This application uses real-time
data from Open Meteo API and the powerful Gemini 2.5 AI model to provide
accurate and informative answers.
""")

# Location selector
with st.expander("Change Location", expanded=False):
    col1, col2 = st.columns(2)
    with col1:
        new_lat = st.number_input(
            "Latitude", 
            min_value=-90.0, 
            max_value=90.0, 
            value=st.session_state.current_lat,
            step=0.0001,
            format="%.4f"
        )
    with col2:
        new_lon = st.number_input(
            "Longitude", 
            min_value=-180.0, 
            max_value=180.0, 
            value=st.session_state.current_lon,
            step=0.0001,
            format="%.4f"
        )
    
    update_button = st.button("Update Location")
    if update_button:
        if new_lat != st.session_state.current_lat or new_lon != st.session_state.current_lon:
            st.session_state.current_lat = new_lat
            st.session_state.current_lon = new_lon
            st.session_state.api_data_cache = {}  # Clear cache when location changes
            st.success(f"Location updated to: {new_lat}, {new_lon}")
            st.rerun()

# Function to refresh data if needed
def refresh_data_if_needed():
    """Refresh the cached API data if it's older than 30 minutes"""
    current_time = datetime.now()
    if (current_time - st.session_state.last_cache_update).seconds > 1800:  # 30 minutes
        with st.spinner("Refreshing climate data..."):
            # Get current data
            try:
                weather_data = get_current_weather(st.session_state.current_lat, st.session_state.current_lon)
                climate_data = get_climate_change_data(st.session_state.current_lat, st.session_state.current_lon)
                air_quality_data = get_air_quality_data(st.session_state.current_lat, st.session_state.current_lon)
                satellite_data = get_satellite_imagery_data(st.session_state.current_lat, st.session_state.current_lon)
                flood_data = get_flood_data(st.session_state.current_lat, st.session_state.current_lon)
                
                # Cache the data
                st.session_state.api_data_cache = {
                    'weather': weather_data,
                    'climate': climate_data,
                    'air_quality': air_quality_data,
                    'satellite': satellite_data,
                    'flood': flood_data
                }
                st.session_state.last_cache_update = current_time
            except Exception as e:
                st.error(f"Error refreshing data: {str(e)}")

# Refresh data if needed
refresh_data_if_needed()

# Display current weather conditions if available
if 'weather' in st.session_state.api_data_cache:
    st.markdown("### Current Weather Conditions")
    display_weather_summary(st.session_state.api_data_cache['weather'])

# Chat interface
st.markdown("### Ask a Question")
st.markdown("Examples: *What's the current temperature?* | *How has air quality changed?* | *What are the climate change projections?*")

# Improved chat input
col1, col2 = st.columns([3, 1])
with col1:
    user_question = st.text_input("Your question about climate or weather:", key="question_input")
with col2:
    st.markdown("&nbsp;")  # Add some space
    submit_button = st.button("📤 Submit", key="submit_button", use_container_width=True)

if submit_button:
    if not user_question:
        st.warning("Please enter a question.")
    else:
        with st.spinner("Thinking..."):
            # Show a temporary message while waiting
            message_placeholder = st.empty()
            message_placeholder.info("Connecting to AI service and analyzing climate data...")
            
            # Get the AI response
            response = get_ai_response(
                user_question, 
                st.session_state.api_data_cache, 
                st.session_state.current_lat, 
                st.session_state.current_lon
            )
            
            # Clear the temporary message
            message_placeholder.empty()
            
            # Add to chat history
            st.session_state.chat_history.append({"question": user_question, "answer": response})
            
        # Clear the input
        st.rerun()

# Display chat history in reverse order (newest first)
if st.session_state.chat_history:
    st.markdown("### Conversation History")
    
    # Add a clear history button
    if st.button("🗑️ Clear History", key="clear_history", type="secondary", help="Clear your conversation history"):
        st.session_state.chat_history = []
        st.rerun()
    
    for i, exchange in enumerate(reversed(st.session_state.chat_history)):
        # Create a custom chat-like UI
        question_container = st.container(border=False)
        with question_container:
            st.markdown(f"**🙋 You asked:** {exchange['question']}")
        
        # Add some space between question and answer
        st.markdown("&nbsp;")
        
        answer_container = st.container(border=True)
        with answer_container:
            st.markdown(f"**🌍 ClimateGPT:**")
            st.markdown(exchange['answer'])
            
            # Add visualization button for relevant questions
            if any(keyword in exchange['question'].lower() for keyword in ['temperature', 'rain', 'precipitation', 'forecast', 'trend', 'climate', 'weather']):
                cols = st.columns([1, 3])
                with cols[0]:
                    if st.button(f"📊 Visualize", key=f"viz_{i}", help="Generate a data visualization for this question"):
                        with st.spinner("Creating visualization..."):
                            fig = create_data_visualization(
                                exchange['question'],
                                st.session_state.api_data_cache
                            )
                            if fig:
                                st.pyplot(fig)
                            else:
                                st.info("No relevant data available for visualization.")
        
        # Add space between conversation items
        st.markdown("---")

# Footer
st.markdown("---")
st.markdown("Data provided by Open Meteo API | AI powered by Gemini 2.5 via OpenRouter")
