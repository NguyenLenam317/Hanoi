import requests
import json
from datetime import datetime, timedelta
import pandas as pd

# Base URLs for the Open Meteo API endpoints
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
CLIMATE_URL = "https://climate-api.open-meteo.com/v1/climate"
AIR_QUALITY_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
SATELLITE_URL = "https://satellite-api.open-meteo.com/v1/archive"
FLOOD_URL = "https://flood-api.open-meteo.com/v1/flood"

def handle_api_error(response):
    """Handle API errors with appropriate error messages"""
    try:
        error_data = response.json()
        error_msg = error_data.get('reason', 'Unknown error')
        return f"API Error ({response.status_code}): {error_msg}"
    except:
        return f"API Error ({response.status_code}): Unable to parse error message"

def get_current_weather(latitude, longitude):
    """
    Fetch current weather and forecast data from Open Meteo API
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: JSON response with weather data
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "temperature_2m,relative_humidity_2m,dew_point_2m,apparent_temperature,precipitation_probability,precipitation,rain,showers,weather_code,surface_pressure,cloud_cover,visibility",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,rain_sum,weather_code",
        "current_weather": True,
        "timezone": "auto",
        "forecast_days": 7,
    }
    
    try:
        response = requests.get(FORECAST_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = handle_api_error(response)
        raise Exception(f"Failed to fetch weather data: {error_msg}")
    except Exception as e:
        raise Exception(f"Failed to fetch weather data: {str(e)}")

def get_climate_change_data(latitude, longitude):
    """
    Fetch climate change data from Open Meteo Climate API
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: JSON response with climate change data
    """
    # Set date range for climate data (historical and projections)
    start_date = "1950-01-01"
    end_date = "2050-12-31"
    
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "start_date": start_date,
        "end_date": end_date,
        "models": "CMCC_CM2_VHR4,FGOALS_f3_H,EC_Earth3P_HR",  # Using a subset of models for efficiency
        "daily": "temperature_2m_max,temperature_2m_mean,temperature_2m_min,precipitation_sum,wind_speed_10m_mean"
    }
    
    try:
        response = requests.get(CLIMATE_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = handle_api_error(response)
        raise Exception(f"Failed to fetch climate change data: {error_msg}")
    except Exception as e:
        raise Exception(f"Failed to fetch climate change data: {str(e)}")

def get_air_quality_data(latitude, longitude):
    """
    Fetch air quality data from Open Meteo Air Quality API
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: JSON response with air quality data
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,ozone,sulphur_dioxide,uv_index",
        "timezone": "auto",
        "past_days": 7,
        "forecast_days": 5
    }
    
    try:
        response = requests.get(AIR_QUALITY_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = handle_api_error(response)
        raise Exception(f"Failed to fetch air quality data: {error_msg}")
    except Exception as e:
        raise Exception(f"Failed to fetch air quality data: {str(e)}")

def get_satellite_imagery_data(latitude, longitude):
    """
    Fetch satellite imagery (radiation) data from Open Meteo Satellite API
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: JSON response with satellite data
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "shortwave_radiation,direct_radiation,diffuse_radiation,terrestrial_radiation",
        "models": "satellite_radiation_seamless",
        "past_days": 30
    }
    
    try:
        response = requests.get(SATELLITE_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = handle_api_error(response)
        raise Exception(f"Failed to fetch satellite data: {error_msg}")
    except Exception as e:
        raise Exception(f"Failed to fetch satellite data: {str(e)}")

def get_flood_data(latitude, longitude):
    """
    Fetch flood data from Open Meteo Flood API
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: JSON response with flood data
    """
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "daily": "river_discharge,river_discharge_mean,river_discharge_max",
        "models": "seamless_v4",
        "past_days": 30,
        "forecast_days": 14,
        "ensemble": False  # Set to True if you want ensemble forecasts
    }
    
    try:
        response = requests.get(FLOOD_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.HTTPError as e:
        error_msg = handle_api_error(response)
        raise Exception(f"Failed to fetch flood data: {error_msg}")
    except Exception as e:
        raise Exception(f"Failed to fetch flood data: {str(e)}")

def get_all_climate_data(latitude, longitude):
    """
    Fetch all climate-related data from various Open Meteo APIs
    
    Args:
        latitude (float): Latitude coordinate
        longitude (float): Longitude coordinate
        
    Returns:
        dict: Dictionary containing all climate data
    """
    try:
        weather_data = get_current_weather(latitude, longitude)
        climate_data = get_climate_change_data(latitude, longitude)
        air_quality_data = get_air_quality_data(latitude, longitude)
        satellite_data = get_satellite_imagery_data(latitude, longitude)
        flood_data = get_flood_data(latitude, longitude)
        
        return {
            'weather': weather_data,
            'climate': climate_data,
            'air_quality': air_quality_data,
            'satellite': satellite_data,
            'flood': flood_data
        }
    except Exception as e:
        raise Exception(f"Error fetching climate data: {str(e)}")
