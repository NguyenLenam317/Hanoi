import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

def weather_code_to_description(code):
    """Convert WMO weather code to human-readable description"""
    weather_codes = {
        0: "Clear sky",
        1: "Mainly clear",
        2: "Partly cloudy",
        3: "Overcast",
        45: "Fog",
        48: "Depositing rime fog",
        51: "Light drizzle",
        53: "Moderate drizzle",
        55: "Dense drizzle",
        56: "Light freezing drizzle",
        57: "Dense freezing drizzle",
        61: "Slight rain",
        63: "Moderate rain",
        65: "Heavy rain",
        66: "Light freezing rain",
        67: "Heavy freezing rain",
        71: "Slight snow fall",
        73: "Moderate snow fall",
        75: "Heavy snow fall",
        77: "Snow grains",
        80: "Slight rain showers",
        81: "Moderate rain showers",
        82: "Violent rain showers",
        85: "Slight snow showers",
        86: "Heavy snow showers",
        95: "Thunderstorm",
        96: "Thunderstorm with slight hail",
        99: "Thunderstorm with heavy hail"
    }
    
    return weather_codes.get(code, "Unknown")

def display_weather_summary(weather_data):
    """Display a summary of current weather conditions"""
    try:
        if 'current_weather' in weather_data:
            current = weather_data['current_weather']
            
            # Create two columns
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric(
                    label="Temperature", 
                    value=f"{current.get('temperature', 'N/A')}°C",
                    delta=None
                )
                
                # Get weather description from code
                weather_code = current.get('weathercode')
                weather_desc = weather_code_to_description(weather_code) if weather_code is not None else "Unknown"
                st.metric(
                    label="Conditions", 
                    value=weather_desc,
                    delta=None
                )
            
            with col2:
                st.metric(
                    label="Wind Speed", 
                    value=f"{current.get('windspeed', 'N/A')} km/h",
                    delta=None
                )
                st.metric(
                    label="Wind Direction", 
                    value=f"{current.get('winddirection', 'N/A')}°",
                    delta=None
                )
            
            # Show today's forecast if available
            if 'daily' in weather_data and len(weather_data['daily'].get('time', [])) > 0:
                st.markdown("**Today's Forecast:**")
                
                today_idx = 0  # Today is the first entry
                
                today_high = weather_data['daily']['temperature_2m_max'][today_idx]
                today_low = weather_data['daily']['temperature_2m_min'][today_idx]
                precip = weather_data['daily']['precipitation_sum'][today_idx]
                
                cols = st.columns(3)
                cols[0].metric("High", f"{today_high}°C")
                cols[1].metric("Low", f"{today_low}°C")
                cols[2].metric("Precipitation", f"{precip} mm")
        else:
            st.info("Current weather data not available.")
            
    except Exception as e:
        st.error(f"Error displaying weather summary: {str(e)}")

def create_data_visualization(question, data_cache):
    """
    Create a visualization based on the user's question and available data
    
    Args:
        question (str): User's question
        data_cache (dict): Dictionary of climate data
        
    Returns:
        matplotlib.figure.Figure or None: Figure object or None if no relevant visualization
    """
    question = question.lower()
    
    # Temperature trends visualization
    if any(keyword in question for keyword in ['temperature', 'hot', 'cold', 'warm']):
        if 'weather' in data_cache and 'hourly' in data_cache['weather']:
            try:
                # Get hourly temperature data
                temp_data = data_cache['weather']['hourly']['temperature_2m']
                time_data = data_cache['weather']['hourly']['time']
                
                # Convert time strings to datetime objects
                time_objects = [datetime.fromisoformat(t.replace('Z', '+00:00')) for t in time_data]
                
                # Create figure
                fig, ax = plt.subplots(figsize=(10, 6))
                ax.plot(time_objects, temp_data, '-o', markersize=4)
                
                # Set labels and title
                ax.set_xlabel('Time')
                ax.set_ylabel('Temperature (°C)')
                ax.set_title('Temperature Forecast')
                
                # Format x-axis to show only dates
                plt.xticks(rotation=45)
                
                # Add grid
                ax.grid(True, linestyle='--', alpha=0.7)
                
                # Tight layout
                plt.tight_layout()
                
                return fig
            except Exception as e:
                st.error(f"Error creating temperature visualization: {str(e)}")
                return None
    
    # Precipitation visualization
    elif any(keyword in question for keyword in ['rain', 'precipitation', 'rainfall']):
        if 'weather' in data_cache and 'hourly' in data_cache['weather']:
            try:
                # Get precipitation data
                if 'precipitation' in data_cache['weather']['hourly']:
                    precip_data = data_cache['weather']['hourly']['precipitation']
                    time_data = data_cache['weather']['hourly']['time']
                    
                    # Convert time strings to datetime objects
                    time_objects = [datetime.fromisoformat(t.replace('Z', '+00:00')) for t in time_data]
                    
                    # Create figure
                    fig, ax = plt.subplots(figsize=(10, 6))
                    ax.bar(time_objects, precip_data, width=0.01, alpha=0.7)
                    
                    # Set labels and title
                    ax.set_xlabel('Time')
                    ax.set_ylabel('Precipitation (mm)')
                    ax.set_title('Precipitation Forecast')
                    
                    # Format x-axis to show only dates
                    plt.xticks(rotation=45)
                    
                    # Tight layout
                    plt.tight_layout()
                    
                    return fig
                else:
                    return None
            except Exception as e:
                st.error(f"Error creating precipitation visualization: {str(e)}")
                return None
    
    # Climate change visualization
    elif any(keyword in question for keyword in ['climate change', 'warming', 'climate projection']):
        if 'climate' in data_cache and 'daily' in data_cache['climate']:
            try:
                climate_data = data_cache['climate']
                
                # Get time, temperature mean data
                if 'temperature_2m_mean' in climate_data['daily']:
                    time_data = climate_data['daily']['time']
                    temp_data = climate_data['daily']['temperature_2m_mean']
                    
                    # Convert to datetime and filter for one data point per year
                    years = []
                    annual_temps = []
                    
                    current_year = None
                    year_temps = []
                    
                    for i, time_str in enumerate(time_data):
                        year = int(time_str.split('-')[0])
                        
                        if current_year != year:
                            if current_year is not None:
                                years.append(current_year)
                                annual_temps.append(sum(year_temps) / len(year_temps))
                            
                            current_year = year
                            year_temps = [temp_data[i]]
                        else:
                            year_temps.append(temp_data[i])
                    
                    # Add the last year
                    if year_temps:
                        years.append(current_year)
                        annual_temps.append(sum(year_temps) / len(year_temps))
                    
                    # Create figure
                    fig, ax = plt.subplots(figsize=(10, 6))
                    
                    # Plot the data
                    ax.plot(years, annual_temps, '-o', markersize=4)
                    
                    # Calculate and plot trend line
                    z = np.polyfit(years, annual_temps, 1)
                    p = np.poly1d(z)
                    ax.plot(years, p(years), "r--", alpha=0.7)
                    
                    # Add trend rate text
                    trend_rate = z[0] * 10  # Degrees per decade
                    ax.text(0.05, 0.95, f"Trend: {trend_rate:.2f}°C per decade", 
                            transform=ax.transAxes, fontsize=10,
                            verticalalignment='top', bbox=dict(boxstyle='round', facecolor='white', alpha=0.5))
                    
                    # Set labels and title
                    ax.set_xlabel('Year')
                    ax.set_ylabel('Average Temperature (°C)')
                    ax.set_title('Annual Temperature Trend')
                    
                    # Add grid
                    ax.grid(True, linestyle='--', alpha=0.7)
                    
                    # Tight layout
                    plt.tight_layout()
                    
                    return fig
                else:
                    return None
            except Exception as e:
                st.error(f"Error creating climate change visualization: {str(e)}")
                return None
    
    # Air quality visualization
    elif any(keyword in question for keyword in ['air quality', 'pollution', 'pm2.5', 'pm10']):
        if 'air_quality' in data_cache and 'hourly' in data_cache['air_quality']:
            try:
                aq_data = data_cache['air_quality']
                
                # Choose pollutants to display
                pollutants = []
                if 'pm2_5' in aq_data['hourly']:
                    pollutants.append(('pm2_5', 'PM2.5'))
                if 'pm10' in aq_data['hourly']:
                    pollutants.append(('pm10', 'PM10'))
                
                if not pollutants:
                    return None
                
                # Get time data
                time_data = aq_data['hourly']['time']
                
                # Convert time strings to datetime objects
                time_objects = [datetime.fromisoformat(t.replace('Z', '+00:00')) for t in time_data]
                
                # Create figure
                fig, ax = plt.subplots(figsize=(10, 6))
                
                # Plot each pollutant
                for poll_key, poll_name in pollutants:
                    poll_data = aq_data['hourly'][poll_key]
                    ax.plot(time_objects, poll_data, '-o', markersize=3, label=poll_name)
                
                # Set labels and title
                ax.set_xlabel('Time')
                ax.set_ylabel('Concentration (μg/m³)')
                ax.set_title('Air Quality Data')
                
                # Add legend
                ax.legend()
                
                # Format x-axis to show only dates
                plt.xticks(rotation=45)
                
                # Add grid
                ax.grid(True, linestyle='--', alpha=0.7)
                
                # Tight layout
                plt.tight_layout()
                
                return fig
            except Exception as e:
                st.error(f"Error creating air quality visualization: {str(e)}")
                return None
    
    # Default: return None if no relevant visualization
    return None
