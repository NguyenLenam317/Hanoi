import requests
import json
import os
import streamlit as st
import time
from datetime import datetime

# OpenRouter API constants
OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "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")

# Model settings - using multiple model options to improve reliability
MODELS = [
    "google/gemini-1.5-pro",
    "anthropic/claude-3-haiku:beta",
    "anthropic/claude-3-sonnet:beta",
    "meta-llama/llama-3-8b-instruct",
    "mistralai/mistral-7b-instruct"
]
DEFAULT_MODEL = "google/gemini-1.5-pro"
MAX_TOKENS = 2000
TEMPERATURE = 0.7  # Slightly higher for more creative responses

def format_data_for_context(data_cache, lat, lon):
    """
    Format climate data for AI context
    
    Args:
        data_cache (dict): Dictionary containing climate data
        lat (float): Latitude coordinate
        lon (float): Longitude coordinate
        
    Returns:
        str: Formatted context string for AI
    """
    context = f"Current location: Latitude {lat}, Longitude {lon}\n"
    context += f"Current date and time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    # Add current weather if available
    if 'weather' in data_cache and data_cache['weather']:
        try:
            weather = data_cache['weather']
            
            # Current weather
            if 'current_weather' in weather:
                current = weather['current_weather']
                weather_code = current.get('weathercode', 'N/A')
                context += "CURRENT WEATHER CONDITIONS:\n"
                context += f"Temperature: {current.get('temperature', 'N/A')}°C\n"
                context += f"Wind speed: {current.get('windspeed', 'N/A')} km/h\n"
                context += f"Wind direction: {current.get('winddirection', 'N/A')}°\n"
                
                # Convert weather code to description
                weather_descriptions = {
                    0: "Clear sky",
                    1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                    45: "Fog", 48: "Depositing rime fog",
                    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
                    56: "Light freezing drizzle", 57: "Dense freezing drizzle",
                    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
                    66: "Light freezing rain", 67: "Heavy freezing rain",
                    71: "Slight snow fall", 73: "Moderate snow fall", 75: "Heavy snow fall",
                    77: "Snow grains",
                    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
                    85: "Slight snow showers", 86: "Heavy snow showers",
                    95: "Thunderstorm", 96: "Thunderstorm with slight hail", 99: "Thunderstorm with heavy hail"
                }
                weather_desc = weather_descriptions.get(weather_code, "Unknown")
                context += f"Current conditions: {weather_desc} (code: {weather_code})\n\n"
            
            # Hourly forecast data for next 24 hours
            if 'hourly' in weather and 'time' in weather['hourly']:
                context += "HOURLY FORECAST (Next 24 hours):\n"
                # Determine the current hour index
                current_hour = datetime.now().hour
                # Get next 24 hours of data
                for i in range(24):
                    try:
                        hour_idx = current_hour + i
                        if hour_idx < len(weather['hourly']['time']):
                            time = weather['hourly']['time'][hour_idx]
                            temp = weather['hourly']['temperature_2m'][hour_idx]
                            
                            # Get additional hourly data if available
                            precip_prob = weather['hourly'].get('precipitation_probability', [0] * len(weather['hourly']['time']))[hour_idx]
                            precip = weather['hourly'].get('precipitation', [0] * len(weather['hourly']['time']))[hour_idx]
                            humidity = weather['hourly'].get('relative_humidity_2m', [0] * len(weather['hourly']['time']))[hour_idx]
                            
                            # Format time to be more readable (just the hour)
                            hour_str = time.split('T')[1].split(':')[0] + ":00"
                            context += f"{hour_str}: {temp}°C, Humidity: {humidity}%, Precipitation: {precip}mm (Probability: {precip_prob}%)\n"
                    except (IndexError, KeyError):
                        continue
                context += "\n"
            
            # Daily forecast
            if 'daily' in weather:
                context += "WEATHER FORECAST (Next 7 days):\n"
                for i in range(min(7, len(weather['daily'].get('time', [])))):
                    date = weather['daily']['time'][i]
                    max_temp = weather['daily']['temperature_2m_max'][i]
                    min_temp = weather['daily']['temperature_2m_min'][i]
                    precip = weather['daily']['precipitation_sum'][i]
                    
                    # Get weather code if available
                    weather_code = weather['daily'].get('weather_code', [0] * len(weather['daily']['time']))[i]
                    weather_descriptions = {
                        0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                        45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Moderate drizzle", 55: "Heavy drizzle",
                        61: "Light rain", 63: "Moderate rain", 65: "Heavy rain",
                        71: "Light snow", 73: "Moderate snow", 75: "Heavy snow",
                        80: "Light showers", 81: "Moderate showers", 82: "Heavy showers", 95: "Thunderstorm"
                    }
                    weather_desc = weather_descriptions.get(weather_code, "")
                    weather_info = f" - {weather_desc}" if weather_desc else ""
                    
                    # Format date to be more readable (e.g., "Mon, Jan 1" instead of "2023-01-01")
                    date_obj = datetime.strptime(date, "%Y-%m-%d")
                    formatted_date = date_obj.strftime("%a, %b %d")
                    
                    context += f"{formatted_date}: High {max_temp}°C, Low {min_temp}°C, Precipitation {precip}mm{weather_info}\n"
                context += "\n"
        except Exception as e:
            context += f"Error parsing weather data: {str(e)}\n\n"
    
    # Add air quality if available
    if 'air_quality' in data_cache and data_cache['air_quality']:
        try:
            aq = data_cache['air_quality']
            
            # Get the most recent hour
            if 'hourly' in aq and 'time' in aq['hourly'] and len(aq['hourly']['time']) > 0:
                latest_idx = -1  # Latest available index
                
                # Get time for context
                latest_time = aq['hourly']['time'][latest_idx].split('T')[1].split(':')[0] + ":00"
                context += f"CURRENT AIR QUALITY (as of {latest_time}):\n"
                
                # PM2.5
                if 'pm2_5' in aq['hourly']:
                    pm25 = aq['hourly']['pm2_5'][latest_idx]
                    # Add interpretation
                    pm25_level = "Good (0-10), Moderate (10-25), Poor (25-50), Very Poor (50-75), Extremely Poor (>75)"
                    context += f"PM2.5: {pm25} μg/m³ - Fine particulate matter\n"
                
                # PM10
                if 'pm10' in aq['hourly']:
                    pm10 = aq['hourly']['pm10'][latest_idx]
                    context += f"PM10: {pm10} μg/m³ - Coarse particulate matter\n"
                
                # Other pollutants with descriptions
                pollutant_descriptions = {
                    'carbon_monoxide': "Carbon monoxide (CO) - Colorless, odorless gas harmful when inhaled",
                    'nitrogen_dioxide': "Nitrogen dioxide (NO₂) - Reddish-brown gas, primary air pollutant",
                    'sulphur_dioxide': "Sulphur dioxide (SO₂) - Toxic gas with strong odor",
                    'ozone': "Ozone (O₃) - Reactive gas, harmful at ground level"
                }
                
                for pollutant in ['carbon_monoxide', 'nitrogen_dioxide', 'sulphur_dioxide', 'ozone']:
                    if pollutant in aq['hourly']:
                        value = aq['hourly'][pollutant][latest_idx]
                        context += f"{pollutant.replace('_', ' ').title()}: {value} μg/m³ - {pollutant_descriptions.get(pollutant, '')}\n"
                
                # Add air quality forecast if available (next 24 hours)
                context += "\nAIR QUALITY FORECAST (Next 24 hours):\n"
                current_hour = datetime.now().hour
                for i in range(0, 24, 3):  # Sample every 3 hours to keep it concise
                    try:
                        hour_idx = current_hour + i
                        if hour_idx < len(aq['hourly']['time']):
                            time = aq['hourly']['time'][hour_idx]
                            hour_str = time.split('T')[1].split(':')[0] + ":00"
                            
                            # Get key pollutants for this hour
                            pm25_val = aq['hourly'].get('pm2_5', [0] * len(aq['hourly']['time']))[hour_idx]
                            ozone_val = aq['hourly'].get('ozone', [0] * len(aq['hourly']['time']))[hour_idx]
                            
                            context += f"{hour_str}: PM2.5: {pm25_val} μg/m³, Ozone: {ozone_val} μg/m³\n"
                    except (IndexError, KeyError):
                        continue
                
                context += "\n"
        except Exception as e:
            context += f"Error parsing air quality data: {str(e)}\n\n"
    
    # Add climate change data summary if available
    if 'climate' in data_cache and data_cache['climate']:
        try:
            climate = data_cache['climate']
            context += "CLIMATE CHANGE PROJECTIONS:\n"
            context += "Historical and projected temperature data available from 1950 to 2050.\n"
            
            # Add a summary of the data available
            models = climate.get('models', [])
            context += f"Climate models used: {', '.join(models)}\n"
            
            # Add information about what variables are available
            variables = []
            if 'daily' in climate:
                for key in climate['daily']:
                    if key != 'time':
                        variables.append(key.replace('_', ' '))
            
            context += f"Variables available: {', '.join(variables)}\n"
            
            # Add temperature projection trends if available
            if 'daily' in climate and 'temperature_2m_mean' in climate['daily'] and 'time' in climate['daily']:
                times = climate['daily']['time']
                temps = climate['daily']['temperature_2m_mean']
                
                # Calculate average temperatures by decade
                decades = {}
                for i, time_str in enumerate(times):
                    try:
                        year = int(time_str.split('-')[0])
                        decade = (year // 10) * 10  # Group by decade
                        
                        if decade not in decades:
                            decades[decade] = []
                        
                        decades[decade].append(temps[i])
                    except (ValueError, IndexError):
                        continue
                
                # Report on key decades
                context += "\nTemperature trends by decade:\n"
                for decade in sorted(decades.keys()):
                    if len(decades[decade]) > 0:
                        avg_temp = sum(decades[decade]) / len(decades[decade])
                        context += f"{decade}s: Average temperature {avg_temp:.1f}°C\n"
            
            context += "\n"
        except Exception as e:
            context += f"Error parsing climate change data: {str(e)}\n\n"
    
    # Add flood data if available
    if 'flood' in data_cache and data_cache['flood']:
        try:
            flood = data_cache['flood']
            
            if 'daily' in flood and 'river_discharge' in flood['daily'] and 'time' in flood['daily']:
                context += "FLOOD DATA AND RIVER CONDITIONS:\n"
                
                # Get current/recent river discharge
                times = flood['daily']['time']
                discharge = flood['daily']['river_discharge']
                
                # Get the most recent data points
                recent_data_points = min(7, len(times))
                context += "Recent river discharge measurements (cubic meters per second):\n"
                
                for i in range(recent_data_points):
                    try:
                        date = times[i]
                        discharge_value = discharge[i]
                        
                        # Format date
                        date_obj = datetime.strptime(date, "%Y-%m-%d")
                        formatted_date = date_obj.strftime("%a, %b %d")
                        
                        context += f"{formatted_date}: {discharge_value} m³/s\n"
                    except (IndexError, ValueError):
                        continue
                
                context += "\n"
        except Exception as e:
            context += f"Error parsing flood data: {str(e)}\n\n"
            
    # Add satellite data if available
    if 'satellite' in data_cache and data_cache['satellite']:
        try:
            satellite = data_cache['satellite']
            
            if 'hourly' in satellite:
                context += "SATELLITE DATA:\n"
                
                # List available variables
                sat_variables = []
                for key in satellite['hourly']:
                    if key != 'time':
                        sat_variables.append(key.replace('_', ' '))
                
                context += f"Available satellite measurements: {', '.join(sat_variables)}\n"
                
                # Add some example recent data if available
                if 'time' in satellite['hourly'] and len(satellite['hourly']['time']) > 0:
                    latest_idx = -1
                    context += "\nMost recent satellite measurements:\n"
                    
                    # Create descriptions for the satellite data types
                    sat_descriptions = {
                        'shortwave_radiation': 'Solar radiation reflected by Earth/atmosphere (W/m²)',
                        'direct_radiation': 'Direct solar radiation on perpendicular surface (W/m²)',
                        'direct_normal_irradiance': 'Solar irradiance on perpendicular surface (W/m²)',
                        'diffuse_radiation': 'Diffuse solar radiation on horizontal surface (W/m²)',
                        'global_tilted_irradiance': 'Global tilted irradiance (W/m²)'
                    }
                    
                    for variable in sat_variables:
                        var_key = variable.replace(' ', '_')
                        if var_key in satellite['hourly']:
                            value = satellite['hourly'][var_key][latest_idx]
                            description = sat_descriptions.get(var_key, '')
                            context += f"{variable.title()}: {value} - {description}\n"
                
                context += "\n"
        except Exception as e:
            context += f"Error parsing satellite data: {str(e)}\n\n"
    
    return context

def get_ai_response(question, data_cache, lat, lon):
    """
    Get AI response using OpenRouter API with flexible model selection
    
    Args:
        question (str): User's question
        data_cache (dict): Dictionary containing climate data
        lat (float): Latitude coordinate
        lon (float): Longitude coordinate
        
    Returns:
        str: AI response
    """
    # Format climate data as context
    climate_context = format_data_for_context(data_cache, lat, lon)
    
    # Create system prompt with instructions - making it more conversational
    system_prompt = """You are a friendly climate and weather assistant with access to real-time and historical climate data.
Your name is ClimateGPT and you provide information about weather, climate change, air quality, and other environmental factors.

Keep your answers SHORT and SIMPLE. Use everyday language that anyone can understand.

When answering:
- Keep responses brief - no more than 3-4 short paragraphs
- Use simple, non-technical language
- Highlight just 1-2 key data points from what's provided
- Explain what the numbers mean in practical terms
- Focus on information relevant to daily life (like "bring an umbrella" or "good day for outdoor activities")
- Avoid complex scientific explanations
- Use bullet points for clarity when listing multiple items
- If asked about weather or climate, focus on the most immediate information
- If you don't have enough information, just say so briefly

Remember: Users want quick, understandable answers they can use right away.
"""

    # Create messages array with simpler structure for easier processing
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"""Here's the weather and climate data:

{climate_context}

Question: {question}

Remember to keep your answer short, simple, and helpful!"""}
    ]
    
    # Try multiple models in sequence if one fails
    for model in MODELS:
        try:
            # Define request payload
            payload = {
                "model": model,  # Use the current model from our list
                "messages": messages,
                "max_tokens": MAX_TOKENS,
                "temperature": TEMPERATURE
            }
            
            # Set headers with API key
            headers = {
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://replit.com",
                "X-Title": "Climate Data Q&A App"
            }
            
            # Make API request with a timeout
            response = requests.post(
                OPENROUTER_API_URL,
                headers=headers,
                data=json.dumps(payload),
                timeout=15  # Set a timeout to avoid hanging requests
            )
            
            # Check if request was successful
            if response.status_code == 200:
                response_data = response.json()
                if 'choices' in response_data and len(response_data['choices']) > 0:
                    ai_response = response_data['choices'][0]['message']['content']
                    return ai_response
                else:
                    # Missing choices in response, try next model
                    continue
            else:
                # Failed request, try next model
                continue
                
        except Exception as e:
            # Exception occurred, try next model
            continue
    
    # If we've tried all models and none worked, provide a simpler fallback response
    try:
        # Prepare a short, simple response with basic weather info
        fallback_response = f"""Sorry, I can't connect to the AI right now. Here's the basic weather info:

"""
        # Add current weather if available
        if 'weather' in data_cache and data_cache['weather'] and 'current_weather' in data_cache['weather']:
            current = data_cache['weather']['current_weather']
            weather_code = current.get('weathercode', 0)
            temp = current.get('temperature', 'N/A')
            
            # Simple weather description
            weather_descriptions = {
                0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast",
                45: "foggy", 48: "foggy", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
                61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow", 75: "heavy snow",
                80: "light showers", 81: "showers", 82: "heavy showers", 95: "thunderstorm"
            }
            weather_desc = weather_descriptions.get(weather_code, "")
            
            fallback_response += f"It's currently {temp}°C with {weather_desc}.\n"
            fallback_response += f"Wind speed is {current.get('windspeed', 'N/A')} km/h.\n"
            
            # Simple advice based on weather
            if weather_code in [0, 1]:
                fallback_response += "\nGreat day to be outside!"
            elif weather_code in [61, 63, 65, 80, 81, 82, 95]:
                fallback_response += "\nYou might need an umbrella today."
            elif weather_code in [71, 73, 75]:
                fallback_response += "\nBundle up, it's snowing!"
            
        else:
            fallback_response += "Sorry, I can't access weather data right now."
        
        return fallback_response
        
    except Exception as e:
        # If everything fails, return a very simple error message
        return "Sorry, I can't access weather data right now. Please try again later."

def check_if_question_needs_data(question):
    """
    Check if a question requires specific climate data
    
    Args:
        question (str): User's question
        
    Returns:
        tuple: (needs_data, data_types)
            needs_data (bool): Whether the question requires climate data
            data_types (list): List of data types needed
    """
    question = question.lower()
    
    # Define keywords for different data types - expanded for better detection
    weather_keywords = [
        'temperature', 'weather', 'rain', 'precipitation', 'humidity', 
        'wind', 'forecast', 'sunny', 'cloudy', 'storm', 'pressure', 'cold',
        'hot', 'warm', 'chilly', 'freezing', 'snow', 'hail', 'sleet', 'drizzle',
        'thunderstorm', 'fog', 'mist', 'shower', 'downpour', 'breeze', 'gust',
        'heatwave', 'frost', 'dew', 'today', 'tomorrow', 'week', 'weekend',
        'outside', 'umbrella', 'raincoat', 'sunscreen', 'celsius', 'fahrenheit',
        'degrees', 'high', 'low', 'maximum', 'minimum', 'feels like', 'real feel'
    ]
    
    climate_keywords = [
        'climate change', 'global warming', 'climate projection', 'warming trend',
        'climate model', 'future climate', 'temperature rise', 'climate pattern',
        'greenhouse', 'emission', 'carbon dioxide', 'co2', 'methane', 'ch4',
        'historical climate', 'climate record', 'climate history', 'climate future',
        'climate impact', 'climate data', 'climate average', 'rising temperature',
        'decade', 'century', 'ipcc', 'paris agreement', 'climate accord',
        'anthropogenic', 'sea level rise', 'climate normal', 'climate anomaly'
    ]
    
    air_quality_keywords = [
        'air quality', 'pollution', 'pm2.5', 'pm10', 'aqi', 'smog',
        'carbon monoxide', 'nitrogen dioxide', 'sulphur dioxide', 'ozone',
        'particulate matter', 'air pollution', 'pollutant', 'clean air',
        'dirty air', 'breathe', 'breathing', 'respiratory', 'lung', 'asthma',
        'indoor air', 'outdoor air', 'air purifier', 'air filter', 'mask',
        'smoke', 'haze', 'exhaust', 'emission', 'carcinogen', 'toxic'
    ]
    
    flood_keywords = [
        'flood', 'river', 'discharge', 'water level', 'flooding', 'flood risk',
        'flood plain', 'flood zone', 'floodwater', 'river flow', 'streamflow',
        'water flow', 'overflow', 'inundation', 'flood warning', 'flood alert',
        'flood forecast', 'flash flood', 'dam', 'levee', 'drainage', 'runoff'
    ]
    
    satellite_keywords = [
        'satellite', 'radiation', 'solar radiation', 'irradiance', 'remote sensing',
        'earth observation', 'satellite data', 'imagery', 'satellite image',
        'shortwave', 'longwave', 'albedo', 'reflectance', 'spectral', 'thermal',
        'infrared', 'uv index', 'ultraviolet', 'sunshine', 'sun exposure',
        'direct radiation', 'diffuse radiation', 'global radiation'
    ]
    
    # Temporal keywords that might indicate needing multiple data types
    temporal_keywords = [
        'trend', 'pattern', 'history', 'historical', 'record', 'past',
        'future', 'forecast', 'prediction', 'projection', 'time series',
        'comparison', 'change', 'difference', 'increase', 'decrease',
        'rise', 'fall', 'fluctuation', 'variation', 'anomaly', 'normal'
    ]
    
    # Location keywords that might indicate needing location-specific data
    location_keywords = [
        'here', 'there', 'this area', 'this location', 'this region',
        'local', 'locally', 'in my area', 'nearby', 'in the vicinity',
        'around me', 'at this latitude', 'at this longitude', 'at these coordinates'
    ]
    
    # Check if the question contains any keywords
    data_types = []
    
    if any(keyword in question for keyword in weather_keywords):
        data_types.append('weather')
    
    if any(keyword in question for keyword in climate_keywords):
        data_types.append('climate')
    
    if any(keyword in question for keyword in air_quality_keywords):
        data_types.append('air_quality')
    
    if any(keyword in question for keyword in flood_keywords):
        data_types.append('flood')
        
    if any(keyword in question for keyword in satellite_keywords):
        data_types.append('satellite')
    
    # If no specific data type is detected but temporal or location keywords exist,
    # we might need general climate data
    if not data_types and (
        any(keyword in question for keyword in temporal_keywords) or
        any(keyword in question for keyword in location_keywords)
    ):
        data_types = ['weather', 'climate']  # Default to these basic types
    
    # If the question is very general about climate or environment, include all data types
    general_climate_keywords = ['climate data', 'environmental data', 'all data', 'everything']
    if any(keyword in question for keyword in general_climate_keywords):
        data_types = ['weather', 'climate', 'air_quality', 'flood', 'satellite']
    
    needs_data = len(data_types) > 0
    
    return needs_data, data_types
